
#####----------------------------------------------------------------------------#####
##### INPUT ARGS
#####----------------------------------------------------------------------------#####
path_to_bam_file=$1;
path_to_output=$2;
selected_genome=$3;
path_to_hg19=$4;
path_to_hg19_mod=$5;
path_to_hg38=$6;
path_to_hg38_mod=$7;
sampleid=$8;

##### EXAMPLES
# path_to_bam_file="/media/hieunguyen/HNSD01/src/ECD_features/input/KABG37.deduplicated.bam"
# path_to_output=/media/hieunguyen/HNSD01/src/ECD_features/input;
# selected_genome="hg19";
# path_to_hg19="/media/hieunguyen/HNSD01/src/ECD_features/resources/hg19.fa";
# path_to_hg38="/media/hieunguyen/HNSD01/src/ECD_features/resources/hg38.fa";

##### EXPORT samtools and bedtools if necessary!
# export PATH=/home/hieunguyen/samtools/bin:$PATH;
# export PATH=/home/hieunguyen/bedtools2/bin:$PATH;

run_methyl_extract="yes";

# sampleid="$(basename -- ${path_to_bam_file})"
#sampleid=${sampleid%.deduplicated*};
# sampleid=${sampleid%_*};


# Use samtools to get the first read
FIRST_READ=$(samtools view $path_to_bam_file | head -n 1)

# Extract the chromosome name (the 3rd field in the SAM format)
CHR_NAME=$(echo $FIRST_READ | awk '{print $3}')

# Check if "chr" is in the chromosome name
if [[ "$CHR_NAME" == *"chr"* ]]; then
    echo "The chromosome name of the first read contains 'chr': $CHR_NAME"
    if [[ ${selected_genome} == "hg19" ]]
    then path_to_fa=${path_to_hg19};
    else
    path_to_fa=${path_to_hg38};
    fi;

else
    echo "The chromosome name of the first read does not contain 'chr': $CHR_NAME"
    if [[ ${selected_genome} == "hg19" ]]
    then path_to_fa=${path_to_hg19_mod};
    else
    path_to_fa=${path_to_hg38_mod};
    fi;

fi



path_to_output=${path_to_output}/${sampleid};
echo -e "Main output directory: " $path_to_output "\n"
mkdir -p ${path_to_output};
#####----------------------------------------------------------------------------#####
##### Remove unmapped and un-pair reads from bam file
#####----------------------------------------------------------------------------#####
echo -e "Remove unmapped and unpaired reads from bam file ..."
samtools view -h -f 3 ${path_to_bam_file} | samtools sort -n -@ 5 -o tmp.bam;
samtools view -h tmp.bam | awk -f preprocessing_script.awk - > tmp.sam;

echo -e "Sort and index bam file ..."
samtools sort -@ 5 -O BAM -o ${path_to_output}/${sampleid}.sorted.bam tmp.sam;
rm -rf tmp.sam;
rm -rf tmp.bam
samtools index -@ 5 ${path_to_output}/${sampleid}.sorted.bam

echo -e "Finished! Use the new bam file for downstream tasks"

#####----------------------------------------------------------------------------#####
##### re assign path_to_bam_file
path_to_bam_file=${path_to_output}/${sampleid}.sorted.bam;

echo -e "Working on sample " $sampleid "\n";
echo -e "Sample saved at " ${path_to_bam_file} "\n";



echo -e "Using the following hg file: \n";
echo $path_to_fa;

path_to_short_bam=${path_to_output}/short_bam;
mkdir -p ${path_to_short_bam};
path_to_long_bam=${path_to_output}/long_bam;
mkdir -p ${path_to_long_bam};
path_to_flen=${path_to_output}/flen;
mkdir -p ${path_to_flen};
path_to_em=${path_to_output}/EM;
mkdir -p ${path_to_em};

##### Extract fragment lengths from bam file
samtools view ${path_to_bam_file} | cut -f9 > ${path_to_flen}/${sampleid}.flen.txt;

##### Split bam into short and long bam
samtools view -f 2 -h ${path_to_bam_file} | \
  awk 'substr($0,1,1)=="@" || ($9 >= 50 && $9 <= 150) || ($9 <= -50 && $9 >= -150)' | \
  samtools view -b > ${path_to_short_bam}/${sampleid}.short.bam;
samtools index ${path_to_short_bam}/${sampleid}.short.bam
samtools view -f 2 -h ${path_to_bam_file} | \
  awk 'substr($0,1,1)=="@" || ($9 > 150 && $9 <= 250) || ($9 < -150 && $9 >= -250)' | \
  samtools view -b > ${path_to_long_bam}/${sampleid}.long.bam;
samtools index ${path_to_long_bam}/${sampleid}.long.bam;

##### Extract end motif from bam file
samtools view -@ 4 -q 30 -f 2 ${path_to_bam_file} | awk '{if($9 > 0) {start=$4 - 1; end= $4 - 1 + 4; name= $1"_"$9; strand = "+"} else {next}; print $3 "\t" start "\t" end "\t" name "\t" "1" "\t" strand}' > ${sampleid}.endcoord4bp.bed;
bedtools getfasta -s -name -tab -fi ${path_to_fa} -bed ${sampleid}.endcoord4bp.bed  > ${path_to_em}/${sampleid}.endmotif4bp.txt
rm -rf ${sampleid}.endcoord4bp.bed;

##### bismark methylation extract
# bismark="/media/hieunguyen/HNSD01/src/ECD_features/github/Bismark-0.24.2";
# if [[ ${run_methyl_extract} == "yes" ]]
# then mkdir -p ${path_to_output}/methylation_extract && samtools sort -n -@ 20 ${path_to_bam_file} -o ${path_to_output}/methylation_extract/${sampleid}.qname_sorted.bam && \
# ${bismark}/bismark_methylation_extractor --parallel 20 --paired-end --comprehensive --bedGraph --zero_based --output ${path_to_output}/methylation_extract ${path_to_output}/methylation_extract/${sampleid}.qname_sorted.bam;
# rm -rf ${path_to_output}/methylation_extract/${sampleid}.qname_sorted.bam*;
# fi;

touch ${path_to_output}/sample_${sampleid}.finished.txt;
