# GW_pipeline_detail

## Purpose

The **GW_pipeline_detail** folder provides a genome-wide analysis pipeline for cfDNA, MRD, and related research. It includes scripts, workflows, and resources for automated data processing and reporting.

## Folder Structure

- `src/` : Main pipeline scripts and modules.
- `run/` : Example SLURM and local execution scripts.
- `log/` : Pipeline execution logs.
- `sheet/` : Sample sheets and metadata files.
- `nextflow/` : Nextflow workflow and configuration files.
- `output/` : Pipeline results and reports.

## Usage

### 1. Prepare Input Data

- Place your sample sheet (CSV/TSV) in the `sheet/` directory.
- Ensure BAM/FASTQ and resource files are available in the specified locations.

### 2. Configure Parameters

- Edit the SLURM script (`run/run.sh`) and replace all `{{...}}` placeholders:
  - `partition`: SLURM partition name.
  - `num_cpus`: Number of CPU cores.
  - `num_mem`: Memory allocation (e.g., 16G).
  - `path_to_log`: Path to log file.
  - `conda_env`: Conda environment name (with Nextflow installed).
  - `path_to_sheet`: Path to your sample sheet.
  - `path_to_pipeline`: Path to the pipeline folder.
  - `output_dir`: Output directory for results.
  - `path_to_resource`: Path to resource files.

### 3. Run the Pipeline

- Submit the SLURM job:
  ```
  sbatch run/run.sh
  ```
- The pipeline uses Nextflow for workflow management and will generate a report (`report.html`) in the output directory.

### 4. Check Results

- Find processed data and reports in the `output/` directory.
- Review logs in the `log/` directory for troubleshooting.