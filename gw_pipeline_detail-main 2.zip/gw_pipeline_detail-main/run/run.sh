#!/bin/bash

#SBATCH --job-name=GW_pipeline_detail
#SBATCH --partition={{partition}} # the partition to submit to
#SBATCH -c {{num_cpus}}
#SBATCH --mem={{num_mem}} # example: 2G
#SBATCH --output={{path_to_log}} # the path to the log file

source activate {{conda_env}} # nextflow 22.10

#################################################################################################
SampleSheet={{path_to_sheet}} # the path to the sample sheet
working_dir={{path_to_pipeline}} # the path to the pipeline folder
OUTDIR={{output_dir}}; # the path to the output directory
RESOURCE={{path_to_resource}} # the path to the resource directory
#################################################################################################
mkdir -p $OUTDIR

config_mode="_slurm"
nextflow_dir=${working_dir}/nextflow
SRC=${working_dir}/src
work_dir=$OUTDIR/work
report_file=$OUTDIR/report.html

nextflow run $nextflow_dir/nextflow.nf \
    -c $nextflow_dir/config${config_mode}.config \
    --SampleSheet $SampleSheet \
    --OUTDIR $OUTDIR \
    --SRC $SRC \
    --RESOURCE $RESOURCE \
    -w $work_dir \
    -with-report $report_file -resume
