#!/usr/bin/env python
# coding: utf-8

# In[148]:


import pickle
import sys

# Replace 'your_file.pkl' with the path to your .pkl file
file_path = sys.argv[1]
output_save_feature = sys.argv[2]


# In[149]:


# Open the file in binary mode for reading ('rb')
with open(file_path, 'rb') as file:
    # Load the data from the file
    data = pickle.load(file)

# Now you can use the 'data' variable which contains the deserialized object
print(data)


# In[150]:


sample_specific = list(data.keys())[0]
sample_specific


# In[151]:


df=data[sample_specific]
df


# In[152]:


import pandas as pd
import numpy as np

# Assuming 'df' is your DataFrame

# Flatten the DataFrame values (excluding the first column if it's non-numeric like IDs or labels)
values = df.iloc[:, 1:].values.flatten()

# Now 'values' is a long 1D numpy array
# If you specifically need a list, you can convert it as follows:
values_list = values.tolist()

# 'values' or 'values_list' is your long vector of all data points
print(values)
# Or for the list version
print(values_list)


# In[153]:



# In[154]:


sum(values_list[1:256])


# In[155]:


sum(values_list)


# In[156]:




# In[157]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming values_list is already defined
# Filter the list to include only values greater than 0
filtered_values = [value for value in values_list if value > 0]



# In[158]:


import numpy as np
from scipy.stats import gaussian_kde
import matplotlib.pyplot as plt

# Assuming filtered_values is a list of your data values > 0
data1 = np.array(filtered_values)

# Perform Kernel Density Estimation (KDE)
kde = gaussian_kde(data1, bw_method=0.5)  # bw_method corresponds to bw_adjust in sns.kdeplot

# Generate x values (points where you want to evaluate the density)
x = np.linspace(min(data1), max(data1), 1000)



# Adjust bw_method to match Seaborn's bw_adjust effect more closely
bw_method_adjusted = 0.1  # This is an example; you might need to experiment with this value
kde = gaussian_kde(data1, bw_method=bw_method_adjusted)

# Recalculate y with the adjusted bw_method
y = kde(x)




# In[159]:


import pandas as pd

# Replace 'Downloads/Hieu_metadata_new_feature.xlsx' with the path to your Excel file

# Read the Excel file into a pandas DataFrame
metadata = pd.DataFrame(list(data.keys()))
metadata.columns = ['SampleID']

# Display the first few rows of the DataFrame
print(metadata.head())


# In[160]:


import pandas as pd
import numpy as np

# Assuming 'metadata' is your DataFrame containing SampleIDs
# Assuming 'data' is your dictionary with keys as SampleIDs and values as DataFrames

# Initialize an empty DataFrame for the density matrix
# The columns will be the features (assuming all DataFrames in 'data' have the same columns)
# We can extract the column names from any of the DataFrames in 'data'
sample_id_example = next(iter(data))  # Get the first SampleID from the 'data' dictionary as an example
features = data[sample_id_example].columns  # Extract feature names from this DataFrame

# Initialize the density matrix DataFrame with SampleIDs as index and features as columns
density_matrix = pd.DataFrame(columns=features, index=metadata['SampleID'])



# In[161]:


density_matrix


# In[162]:


df=data[sample_specific]


# In[163]:


# Flatten the DataFrame values (excluding the first column if it's non-numeric like IDs or labels)
values = df.iloc[:, 1:].values.flatten()


# In[164]:


# Now 'values' is a long 1D numpy array
# If you specifically need a list, you can convert it as follows:
values_list = values.tolist()


# In[165]:


values_list


# In[166]:


filtered_values = [value for value in values_list if value > 0]


# In[167]:


filtered_values


# In[ ]:





# In[168]:


import pandas as pd
import numpy as np
from scipy.stats import gaussian_kde

# Example: Assuming 'data' is a dictionary with 'SampleID' as keys, and the corresponding data as values.

# Determine the global x range (adjust as needed)
global_min = 0  # Adjust based on the overall data range you're interested in
global_max = 1  # Adjust based on the overall data range you're interested in
x = np.linspace(global_min, global_max, 1000)  # Fixed x range for density calculations

# Initialize a DataFrame to store density values for each sample
density_matrix = pd.DataFrame(index=metadata['SampleID'], columns=range(len(x)))

for sample_id in metadata['SampleID']:
    if sample_id in data:
        # Extract and prepare the sample data
        sample_data = data[sample_id]  # Assuming this retrieves a DataFrame
        values = sample_data.iloc[:, 1:].values.flatten()  # Flatten the data excluding the first column
        filtered_values = values[values > 0]  # Filter to keep only values > 0
        
        # Perform KDE and calculate densities over the fixed x range
        if len(filtered_values) > 0:
            kde = gaussian_kde(filtered_values, bw_method=0.5)  # Adjust bw_method as needed
            y = kde(x)  # Calculate density values
        else:
            y = np.zeros(len(x))  # Use zeros if there are no values > 0

        density_matrix.loc[sample_id] = y  # Store the density values in the matrix

# Now, 'density_matrix' contains density values for each sample across the fixed x range
print(density_matrix.head())



# In[169]:


# Remove rows that contain any NaN values
cleaned_density_matrix = density_matrix.dropna()

# Print the first few rows of the cleaned DataFrame
print(cleaned_density_matrix.head())


# In[170]:


cleaned_density_matrix.to_csv(output_save_feature, index=True, header=True)


# In[171]:


a = cleaned_density_matrix.reset_index()
a.columns = [ str(c) for c in a.columns]
a


# In[172]:


# b = pd.read_csv('/mnt/DATASM14/hieunho/hieu_project/cancer_classification/input/ECD_cfDNA/TM_feature_v0.2/TM_feature_v0.2_FLENx450/feature_old.csv')
# print(b.shape)
# a = a[b.columns]
# b = pd.concat([b, a])
# print(b.shape)
# b.to_csv('/mnt/DATASM14/hieunho/hieu_project/cancer_classification/input/ECD_cfDNA/TM_feature_v0.2/TM_feature_v0.2_FLENx450/feature.csv', index = None)


# In[ ]:





# In[ ]:




