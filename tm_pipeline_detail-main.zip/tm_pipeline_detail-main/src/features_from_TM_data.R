gc()
rm(list = ls())

library(QDNAseq)
library(Biobase)
library(dplyr)
library(tidyverse)
library(GenomicRanges)
library(Repitools)
library(WGSmapp)
library(BSgenome.Hsapiens.UCSC.hg38)
library(hash)
library(testit)
library(argparse)

parser <- ArgumentParser()

parser$add_argument("-i", "--input", action="store", 
                    help="Path to input preprocessed BAM files")
parser$add_argument("-o", "--output", action="store", 
                    help="Path to save all output")
parser$add_argument("-s", "--src", action="store", 
                    help="Path to SRC")
parser$add_argument("-t", "--target_bedfile", action="store", 
                    help="Path to target_bedfile")
parser$add_argument("-sa", "--sample", action="store", 
                    help="sample")
parser$add_argument("-f", "--feature_type", action="store", 
                    help="types of feature")

args <- parser$parse_args()

path.to.sample.input <- args$input
path.to.output <- args$output
sample <- args$sample
path.to.target.bedfile <- args$target_bedfile
path.to.main.src <- args$src
feature_type <- args$feature_type

bedfile <- read.csv(path.to.target.bedfile, sep = "\t", header = FALSE) %>%
  rowwise() %>%
  mutate(region.name = sprintf("%s:%s-%s", V1, V2, V3))

output <- hash()

#####----------------------------------------------------------------------#####
##### FLEN
#####----------------------------------------------------------------------#####
generate_flen_feature <- function(input.path){
  flendf <- read.csv(input.path, header = FALSE, col.names = c("flen")) %>%
    rowwise() %>%
    mutate(abs.flen = abs(flen))
  if (nrow(flendf) != 0){
    flen.count <- table(flendf$abs.flen) %>% as.data.frame()
    colnames(flen.count) <- c("size", "count")
    flen.count$size <- as.numeric(as.character(flen.count$size))
    flen.count <- subset(flen.count, flen.count$size >= 100 & flen.count$size <= 250)
    
    flen.count <- flen.count %>% rowwise() %>%
      mutate(freq = count / sum(flen.count$count))
    
    flen.count <- flen.count[order(flen.count$size), ]
    
    output.flendf <- data.frame(size = seq(100, 250), count = 0)
    output.flendf <- merge(output.flendf, flen.count, by.x = "size", by.y = "size", all.x = TRUE)
    output.flendf[is.na(output.flendf$freq), ] <- 0
    
    output.flendf <- subset(output.flendf, select = c(size, freq))
    return(output.flendf)  
  }
}

#####----------------------------------------------------------------------#####
##### EM
#####----------------------------------------------------------------------#####
generate_em_feature <- function(input.path){
  emdf <- read.csv(input.path, sep = "\t", header = FALSE, col.names = c("read", "motif")) %>% subset(select = c(motif)) 
  emdf$motif <- toupper(emdf$motif)
  
  emdf.count <- table(emdf$motif) %>% as.data.frame()
  if (nrow(emdf.count) != 0){
    colnames(emdf.count) <- c("motif", "count")
    emdf.count <- subset(emdf.count, grepl("N", emdf.count$motif) == FALSE)
    emdf.count <- emdf.count %>% rowwise() %>%
      mutate(freq = count/sum(emdf.count$count))
    emdf.count <- subset(emdf.count, select = c(motif, freq))
    return(emdf.count)    
  }
}

#####----------------------------------------------------------------------#####
##### GENERATE QDNAseq BINS from target bed file
#####----------------------------------------------------------------------#####
if (file.exists(file.path(path.to.main.src, "TMD450_bins.rds")) == FALSE){
  source(file.path(path.to.main.src, "generate_target_bins_object.R"))
} else {
  bins <- readRDS(file.path(path.to.main.src, "TMD450_bins.rds"))
}

#####----------------------------------------------------------------------#####
##### PREPARATION
#####----------------------------------------------------------------------#####
print("Running some preparation steps ...")
dir.create(path.to.output, showWarnings = FALSE, recursive = TRUE)

if (feature_type == 'FLEN') {

      all.paths <- list(FLEN = Sys.glob(file.path(path.to.sample.input, sprintf("%s.FLEN.txt", sample))))

      for (filetype in names(all.paths)){
        print(filetype)
        assert(length(all.paths[[filetype]]) == 1)
      }

      print("Generating FLEN features ...")
      output.flendf <- generate_flen_feature(all.paths[["FLEN"]][[1]])

      colnames(output.flendf)[which(colnames(output.flendf) == "freq")] <- sample
      output[["FLEN"]] <- output.flendf

} else if (feature_type == 'EM') {

      all.paths <- list(EM = Sys.glob(file.path(path.to.sample.input, sprintf("%s.EM.txt", sample))))

      for (filetype in names(all.paths)){
        print(filetype)
        assert(length(all.paths[[filetype]]) == 1)
      }

      print("Generating EM features ...")
      emdf.count <- generate_em_feature(all.paths[["EM"]][[1]])

      colnames(emdf.count)[which(colnames(emdf.count) == "freq")] <- sample
      output[["EM"]] <- emdf.count

} else if (feature_type == 'CNA_COUNT') {

      path.to.bamfile <- file.path(path.to.sample.input, sprintf("%s.sorted.bam", sample))
      readCounts <- binReadCounts(bins, bamfiles = path.to.bamfile)
      readCountsFiltered <- applyFilters(readCounts, residual=FALSE, blacklist=FALSE)
      readCountsFiltered <- estimateCorrection(readCountsFiltered, variables = "gc")

      copyNumbers <- new("QDNAseqCopyNumbers", 
                        bins = featureData(readCountsFiltered), 
                        copynumber = readCountsFiltered@assayData$counts,
                        phenodata = phenoData(readCountsFiltered))

      copyNumbersNormalized <- normalizeBins(copyNumbers)
      copyNumbersSmooth <- smoothOutlierBins(copyNumbersNormalized)

      countdf <- readCountsFiltered@assayData$counts %>% as.data.frame() %>% rownames_to_column("region")
      cnadf <- copyNumbersSmooth@assayData$copynumber %>% as.data.frame() %>% as.data.frame() %>% rownames_to_column("region")

      colnames(countdf)[which(colnames(countdf) == sprintf("%s.sorted", sample))] <- sample
      colnames(cnadf)[which(colnames(cnadf) == sprintf("%s.sorted", sample))] <- sample
      output[["COUNT"]] <- countdf
      output["CNA"] <- cnadf
} else if (feature_type == 'FLEN_RATIO') {
      path.to.short.bam <- file.path(path.to.sample.input, sprintf("%s.short.bam", sample))
      shortread.counts <- binReadCounts(bins, bamfiles = path.to.short.bam)
      shortread.counts <- shortread.counts@assayData$counts %>% as.data.frame() %>% rownames_to_column("region")
      colnames(shortread.counts) <- c("region", "short")

      path.to.long.bam <- file.path(path.to.sample.input, sprintf("%s.long.bam", sample))
      longread.counts <- binReadCounts(bins, bamfiles = path.to.long.bam)
      longread.counts <- longread.counts@assayData$counts %>% as.data.frame() %>% rownames_to_column("region")
      colnames(longread.counts) <- c("region", "long")

      ratiodf <- merge(shortread.counts, longread.counts, by.x = "region", by.y = "region")
      ratiodf$ratio_short_long <- ratiodf$short/ratiodf$long
      ratiodf$ratio_short_total <- ratiodf$short/(ratiodf$short + ratiodf$long)

      colnames(ratiodf)[which(colnames(ratiodf) == "ratio_short_long")] <- sprintf("%s.ratio_short_long", sample)
      colnames(ratiodf)[which(colnames(ratiodf) == "ratio_short_total")] <- sprintf("%s.ratio_short_total", sample)

      output[["FLEN_RATIO"]] <- ratiodf
}



#####----------------------------------------------------------------------#####
##### OUTPUT to csv files
#####----------------------------------------------------------------------#####

for (feat in names(output)){
  write.csv(output[[feat]], file.path(path.to.output, sprintf("%s_TMfeature_%s.csv", sample, feat)))
}
