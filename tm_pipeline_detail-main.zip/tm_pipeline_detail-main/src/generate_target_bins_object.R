library(QDNAseq)
library(Biobase)
library(dplyr)
library(tidyverse)
library(GenomicRanges)
library(Repitools)
library(WGSmapp)
library(BSgenome.Hsapiens.UCSC.hg38)
library(hash)

# BiocManager::install("QDNAseq", update = FALSE)
# BiocManager::install("WGSmapp", update = FALSE)
# BiocManager::install("Repitools", update = FALSE)
# install.packages("/media/hieunguyen/HNSD01/src/ECD_features/resources/BSgenome.Hsapiens.UCSC.hg38_1.4.5.tar.gz", type = "source", repos = NULL)

#####----------------------------------------------------------------------#####
##### INPUT ARGS
#####----------------------------------------------------------------------#####
path.to.target.bedfile <- "/media/hieunguyen/HNSD01/src/ECD_features/resources/panel.hg19_liftover_to_hg38.bed"
path.to.main.src <- "/media/hieunguyen/HNSD01/src/ECD_features/src/TMD_data_CNA_GWFP"

bedfile <- read.csv(path.to.target.bedfile, sep = "\t", header = FALSE) %>%
  rowwise() %>%
  mutate(region.name = sprintf("%s:%s-%s", V1, V2, V3))

bin.target <- read.csv(path.to.target.bedfile, sep = "\t", header = FALSE)
bin.target <- bin.target %>% rowwise() %>%
  mutate(region.name = sprintf("%s:%s-%s", str_replace(V1, "chr", ""), V2, V3)) %>%
  mutate(chromosome = V1) %>%
  mutate(start = V2) %>%
  mutate(end = V3) %>%
  subset(select = c(chromosome, start, end, region.name)) 

bin.target$region.name <- as.character(bin.target$region.name)

Granges<- makeGRangesFromDataFrame(data.frame(bin.target), seqnames.field = "chromosome", start.field = "start", end.field = "end", keep.extra.columns = TRUE)

##### Mappability
overlap.idx <- findOverlaps(mapp_hg38, Granges)
mapp_hg38_overlap <- mapp_hg38[queryHits(overlap.idx), ] %>% as.data.frame()
Granges <- cbind(as.data.frame(Granges[subjectHits(overlap.idx), ]), subset(mapp_hg38_overlap, select = c(score)))
tmp <- Granges %>% group_by(region.name) %>%
  summarise_at(vars(score), list(score = mean))
colnames(tmp) <- c("region.name", "mappability")
bin.target <- merge(bin.target, tmp, by.x = "region.name", by.y = "region.name")

##### GC content
Granges<- makeGRangesFromDataFrame(data.frame(bin.target), seqnames.field = "chromosome", start.field = "start", end.field = "end", keep.extra.columns = TRUE)
gc<- gcContentCalc(Granges , organism=BSgenome.Hsapiens.UCSC.hg38, verbose=TRUE)

bin.target$gc <- gc * 100
bin.target$mappability <- bin.target$mappability * 100
bin.target$bases <- NA

bin.target <- bin.target %>% rowwise() %>%
  mutate(chromosome = as.numeric(str_replace(chromosome, "chr", ""))) %>%
  column_to_rownames("region.name")

bin.target <- bin.target[order(bin.target$chromosome, bin.target$start),]
bins <- data.frame(chromosome = bin.target$chromosome, 
                   start = bin.target$start,
                   end = bin.target$end, 
                   bases = bin.target$bases, 
                   gc = bin.target$gc,
                   mappability = bin.target$mappability, 
                   use = TRUE,
                   stringsAsFactors = FALSE)
bins$blacklist <- NA
bins$residual <- 0
bins$chromosome <- sub("^chr", "", bins$chromosome)
rownames(bins) <- sprintf("%s:%i-%i", bins$chromosome, bins$start, 
                          bins$end)

saveRDS(bins, file.path(path.to.main.src, "TMD450_bins.rds"))