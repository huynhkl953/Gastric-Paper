#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import glob, os
import re
import numpy as np
import sys


# In[2]:
region_list_path = sys.argv[1]
path_to_fa = sys.argv[2]
bam = sys.argv[3]
sample = sys.argv[4]
em_template_path = sys.argv[5]
output = sys.argv[6]

# region_list_path = '/mnt/DATASM14/hieunho/hieu_pipeline/TM_pipeline_detail/resource/panel.hg19_liftover_to_hg38.modified.bed'
# path_to_fa = '/mnt/DATASM14/hieunho/hieu_pipeline/TM_pipeline_detail/resource/hg38.fa'
# bam='/mnt/DATASM14/hieunho/hieu_pipeline/TM_pipeline_detail/output/test/Sorted_bam_and_index/K0CAAB69.sorted.bam'
# sample = "K0CAAB69"
# em_template_path = '/mnt/DATASM14/hieunho/hieu_pipeline/TM_pipeline_detail/src/EM_template.csv'
# output='/mnt/DATASM14/hieunho/hieu_pipeline/TM_pipeline_detail/output/test/Prepare_EMx450_and_FLENx450'


# In[3]:


os.system('mkdir -p {}'.format(output))


# In[4]:


region_list = pd.read_csv(region_list_path, header = None)
region_list.columns = ['Region']
region_list


# In[5]:


os.system(
"""
all_regions=$(cat {});
parallel -j 20 samtools view -@ 4 {} {{}} -o {}/{}_{{}}.sorted.bam ::: $all_regions;
parallel -j 20 samtools index -@ 4 {}/{}_{{}}.sorted.bam ::: $all_regions;
""".format(
region_list_path, 
bam, output, sample,
output, sample)
)


# In[6]:


for region in region_list['Region']:
    script = "samtools view -@ 4 {}/{}_{}.sorted.bam | cut -f9 > {}/{}_{}.FLEN.txt".format(
    output, sample, region, output, sample, region)
    print(script)
    os.system(script)


# In[7]:


for region in region_list['Region']:
    script = """samtools view -@ 4 -q 30 -f 2 {}/{}_{}.sorted.bam | awk '{{if($9 > 0 && $4 > 11) {{start=$4 - 1 - 10; end= $4 - 1 - 10 + 4; name= $1"_"$9; strand = "+"}} else {{next}}; print $3 "\\t" start "\\t" end "\\t" name "\\t" "1" "\\t" strand}}' > {}/{}_{}.EM.bed;""".format(
    output, sample, region, output, sample, region)
    print(script)
    os.system(script)


# In[8]:


os.system(
"""
all_regions=$(cat {});
parallel -j 10 "bedtools getfasta -s -name -tab -fi {} -bed {}/{}_{{}}.EM.bed > {}/{}_{{}}.EM.txt" ::: $all_regions;

""".format(
region_list_path, 
path_to_fa,
output, sample, output, sample)
)


# In[9]:


df = pd.DataFrame({
    "size": list(range(100, 251))
})
for region in region_list['Region']:
    flen_path = "{}/{}_{}.FLEN.txt".format(output, sample, region)
    
    try:
        flen = pd.read_csv(flen_path, header = None)
        flen.columns = [region]
        flen = np.abs(flen)
        flen = flen[(flen[region] >= 100) & (flen[region] <= 250)]
        flen = pd.DataFrame(flen.value_counts())
        flen.reset_index(inplace = True)
        flen.columns = ['size', region]
        flen[region] /= flen[region].sum()
        
        df = pd.merge(df, flen, on = 'size', how = 'left')
    except:
        continue
        
df.rename(columns = {"size": "{}.size".format(sample)}, inplace = True)
df.to_csv('{}/{}_TMfeature_FLENx450.csv'.format(output, sample), index = None)


# In[10]:


em_template = pd.read_csv(em_template_path)
df = em_template.copy()

for region in region_list['Region']:
    em_path = "{}/{}_{}.EM.txt".format(output, sample, region)
    try:
        em = pd.read_csv(em_path, header = None, sep = '\t')[[1]]
        em.columns = [region]
        em[region] = [value.upper() for value in em[region]]
        em = pd.DataFrame(em.value_counts())
        em.reset_index(inplace = True)
        em.columns = ['motif', region]
        em = pd.merge(em_template, em)
        em[region] /= em[region].sum()

        df = pd.merge(df, em, on = 'motif', how = 'left')
    except:
        continue
    
df.rename(columns = {"motif": "{}.motif".format(sample)}, inplace = True)
df.to_csv('{}/{}_TMfeature_EMx450.csv'.format(output, sample), index = None)


# In[ ]:




