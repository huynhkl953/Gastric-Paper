import pandas as pd 
import numpy as np 
import os, re, sys, glob
import pickle

input_dir = sys.argv[1]
output_dir = sys.argv[2]
src_dir = sys.argv[3]
feature_type = sys.argv[4]


os.system('mkdir -p {}'.format(output_dir))

#####################  TM_feature_v0.2_FLEN ########################
if feature_type == 'FLEN':
            file_list = glob.glob('{}/*_TMfeature_FLEN.csv'.format(input_dir))

            summary = pd.DataFrame()

            for file in file_list:
                b = pd.read_csv(file)
                sample = b.columns[-1]
                b = b[['size', sample]]
                summary = pd.concat([summary, b]) if len(summary) == 0 else pd.merge(summary, b, on = 'size', how = 'left')

            summary = summary.T
            summary.columns = summary.iloc[0]
            summary = summary.iloc[1:]
            summary.reset_index(inplace = True)
            summary.rename(columns = {'index': "SampleID"}, inplace = True)

            if summary.columns[1] == 100:
                cols = ['SampleID']
                for c in summary.columns[1:]:
                    c_new = str(int(c))
                    cols.append(c_new)
                summary.columns = cols
                
            print(summary.shape)
            summary.to_csv("{}/TMfeature_FLEN.csv".format(output_dir), index = None)

#####################  TM_feature_v0.EM ########################
elif feature_type == 'EM':
            file_list = glob.glob('{}/*_TMfeature_EM.csv'.format(input_dir))

            summary = pd.DataFrame()

            for file in file_list:
                b = pd.read_csv(file)
                sample = b.columns[-1]
                b = b[['motif', sample]]
                summary = pd.concat([summary, b]) if len(summary) == 0 else pd.merge(summary, b, on = 'motif', how = 'left')

            summary = summary.T
            summary.columns = summary.iloc[0]
            summary = summary.iloc[1:]
            summary.reset_index(inplace = True)
            summary.rename(columns = {'index': "SampleID"}, inplace = True)
                
            print(summary.shape)
            summary.to_csv("{}/TMfeature_EM.csv".format(output_dir), index = None)



#####################  TM_feature_v0.CNA_COUNT ########################
elif feature_type == 'CNA_COUNT':
            for sub in ['CNA', 'COUNT']:
                file_list = glob.glob('{}/*_TMfeature_{}.csv'.format(input_dir, sub))

                summary = pd.DataFrame()

                for file in file_list:
                    b = pd.read_csv(file)
                    sample = b.columns[-1]
                    b = b[['region', sample]]
                    summary = pd.concat([summary, b]) if len(summary) == 0 else pd.merge(summary, b, on = 'region', how = 'left')

                summary = summary.T
                summary.columns = summary.iloc[0]
                summary = summary.iloc[1:]
                summary.reset_index(inplace = True)
                summary.rename(columns = {'index': "SampleID"}, inplace = True)
                    
                print(summary.shape)
                summary.to_csv("{}/TMfeature_{}.csv".format(output_dir, sub), index = None)


#####################  TM_feature_v0.FLEN_RATIO ########################
elif feature_type == 'FLEN_RATIO':
            for name, name_to_save in [['ratio_short_long', 'FLEN_RATIO_SHORT_LONG'],
                                        ['ratio_short_total', 'FLEN_RATIO_SHORT_TOTAL']]:
                file_list = glob.glob('{}/*_TMfeature_FLEN_RATIO.csv'.format(input_dir))

                summary = pd.DataFrame()

                for file in file_list:
                    b = pd.read_csv(file)
                    sample = b.columns[-1].split('.')[0]
                    b = b[['region', '{}.{}'.format(sample, name)]]
                    b.columns = ['region', sample]
                    summary = pd.concat([summary, b]) if len(summary) == 0 else pd.merge(summary, b, on = 'region', how = 'left')

                summary = summary.T
                summary.columns = summary.iloc[0]
                summary = summary.iloc[1:]
                summary.reset_index(inplace = True)
                summary.rename(columns = {'index': "SampleID"}, inplace = True)
                    
                print(summary.shape)
                summary.to_csv("{}/TMfeature_{}.csv".format(output_dir, name_to_save), index = None)


#####################  TM_feature_v0.2_FLENx450 ########################
elif feature_type == 'FLENx450':
            file_list = glob.glob('{}/*_TMfeature_FLENx450.csv'.format(input_dir))

            summary = {}

            for file in file_list:
                b = pd.read_csv(file)
                sample = b.columns[0].split('.')[0]
                b.rename(columns = {b.columns[0]: "size"}, inplace = True)
                b.fillna(0, inplace = True)
                summary[sample] = b

            pkl_path = "{}/TMfeature_FLENx450.pkl".format(output_dir)
            csv_path = "{}/TMfeature_FLENx450.csv".format(output_dir)
            with open(pkl_path, 'wb') as f:
                pickle.dump(summary, f)
            os.system('python3 {}/convert_pkl_to_csv_for_EMx450_FLENx450.py {} {}'.format(src_dir, pkl_path, csv_path))

            # encode 2d to 1d
            src = pd.read_csv('{}/TMD_feature_name.csv'.format(src_dir))
            src['region'] = src.apply(lambda x: '{}:{}-{}'.format(x['chrom'], x['start'], x['end']), axis = 1)
            feature_list = src['region'].tolist()

            for sample, data in summary.items():
                data.sort_values('size', ascending = False, inplace = True)
                data.reset_index(drop = True, inplace = True)
                row_list = data['size'].tolist()
                break
            
            new_cols = []
            for motif in row_list:
                for feature in feature_list:
                    new_cols.append('{}_{}'.format(motif, feature))

            sample_list = list(summary.keys())
            sample_list.sort()

            df_sample = pd.DataFrame(sample_list)
            df_sample.columns = ['SampleID']
            df_sample


            df = np.array([])

            sample_list_found = []

            for index in range(len(sample_list)):
                print(index)
                sample = sample_list[index]
                if sample not in summary.keys():
                    continue
                else:
                    sample_list_found.append(sample)
                data = summary[sample].copy()
                data.sort_values('size', ascending = False, inplace = True)
                data.reset_index(drop = True, inplace = True)
                
                for feature in feature_list:
                        if feature not in data.columns.tolist():
                            data[feature] = None
                data = data[feature_list]
                data = data.values.reshape(1, -1)[0]
                data = data.reshape(1, -1)
                
                if len(df) == 0:
                    df = data.copy()
                else:
                    df = np.concatenate((df, data), axis=0)

            df_new = pd.DataFrame(df)
            df_new.columns = new_cols

            df_sample = pd.DataFrame(sample_list_found)
            df_sample.columns = ['SampleID']

            df_new = pd.concat([df_sample, df_new], axis = 1)
            df_new
            
            df_new.to_csv("{}/TMfeature_FLENx450_1D_full.csv".format(output_dir), index = None)


#####################  TM_feature_v0.2_EMx450 ########################
elif feature_type == 'EMx450':
            file_list = glob.glob('{}/*_TMfeature_EMx450.csv'.format(input_dir))

            summary = {}

            for file in file_list:
                b = pd.read_csv(file)
                sample = b.columns[0].split('.')[0]
                b.rename(columns = {b.columns[0]: "motif"}, inplace = True)
                b.fillna(0, inplace = True)
                summary[sample] = b

            pkl_path = "{}/TMfeature_EMx450.pkl".format(output_dir)
            csv_path = "{}/TMfeature_EMx450.csv".format(output_dir)
            with open(pkl_path, 'wb') as f:
                pickle.dump(summary, f)
            os.system('python3 {}/convert_pkl_to_csv_for_EMx450_FLENx450.py {} {}'.format(src_dir, pkl_path, csv_path))

            # encode 2d to 1d
            src = pd.read_csv('{}/TMD_feature_name.csv'.format(src_dir))
            src['region'] = src.apply(lambda x: '{}:{}-{}'.format(x['chrom'], x['start'], x['end']), axis = 1)
            feature_list = src['region'].tolist()

            for sample, data in summary.items():
                data.sort_values('motif', ascending = False, inplace = True)
                data.reset_index(drop = True, inplace = True)
                row_list = data['motif'].tolist()
                break
            
            new_cols = []
            for motif in row_list:
                for feature in feature_list:
                    new_cols.append('{}_{}'.format(motif, feature))

            sample_list = list(summary.keys())
            sample_list.sort()

            df_sample = pd.DataFrame(sample_list)
            df_sample.columns = ['SampleID']
            df_sample


            df = np.array([])

            sample_list_found = []

            for index in range(len(sample_list)):
                print(index)
                sample = sample_list[index]
                if sample not in summary.keys():
                    continue
                else:
                    sample_list_found.append(sample)
                data = summary[sample].copy()
                data.sort_values('motif', ascending = False, inplace = True)
                data.reset_index(drop = True, inplace = True)
                
                for feature in feature_list:
                        if feature not in data.columns.tolist():
                            data[feature] = None
                data = data[feature_list]
                data = data.values.reshape(1, -1)[0]
                data = data.reshape(1, -1)
                
                if len(df) == 0:
                    df = data.copy()
                else:
                    df = np.concatenate((df, data), axis=0)

            df_new = pd.DataFrame(df)
            df_new.columns = new_cols

            df_sample = pd.DataFrame(sample_list_found)
            df_sample.columns = ['SampleID']

            df_new = pd.concat([df_sample, df_new], axis = 1)
            df_new
            
            df_new.to_csv("{}/TMfeature_EMx450_1D_full.csv".format(output_dir), index = None)