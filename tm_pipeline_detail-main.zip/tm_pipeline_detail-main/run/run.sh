#!/bin/bash
#SBATCH --job-name="TM_pipeline_detail"
#SBATCH --partition={{partition}} # the partition to submit to
#SBATCH -c {{num_cpus}}
#SBATCH --mem={{num_mem}} # example: 2G
#SBATCH --output={{path_to_log}} # the path to the log file

source activate {{conda_env}} # nextflow 23.10

################################################################################
SampleSheet={{path_to_sheet}} # the path to the sample sheet
working_dir={{path_to_pipeline}} # the path to the pipeline folder
OUTDIR={{output_dir}}; # the path to the output directory
RESOURCE={{path_to_resource}}; # the path to the resource directory
################################################################################
mkdir -p $OUTDIR

config_mode="_slurm"
nextflow_mode="_full"
work_dir=$OUTDIR/work
report_file=$OUTDIR/report.html

nextflow run $working_dir/nextflow/nextflow${nextflow_mode}.nf \
    -c $working_dir/nextflow/config${config_mode}.config \
    --SampleSheet $SampleSheet \
    --OUTDIR $OUTDIR \
    --working_dir $working_dir \
    --RESOURCE $RESOURCE \
    -w $work_dir \
    -with-report $report_file -resume