# TM_pipeline_detail

## Overview

`TM_pipeline_detail` is a Nextflow-based pipeline for processing targeted sequencing data. It is designed to run on SLURM clusters and supports flexible configuration for different sample sheets, resources, and output directories.

## Structure

- `nextflow/` — Contains Nextflow scripts and configuration files.
- `run/` — Contains example SLURM submission scripts (`run.sh`).
- `sheet/` — Sample sheet templates and examples.
- `resource/` — Reference files and resources required for the pipeline.
- `output/` — Output directory for pipeline results.
- `log/` — Log files generated during pipeline execution.

## Usage

1. **Prepare your sample sheet**  
   Place your sample sheet in the `sheet/` directory or specify its path.

2. **Configure resources**  
   Ensure all required reference files are available in the `resource/` directory.

3. **Edit the SLURM submission script**  
   Update the following variables in `run/run.sh`:
   - `partition` — SLURM partition name
   - `num_cpus` — Number of CPUs to request
   - `num_mem` — Amount of memory (e.g., `16G`)
   - `path_to_log` — Path to log file
   - `conda_env` — Conda environment name (should include Nextflow)
   - `path_to_sheet` — Path to your sample sheet
   - `path_to_pipeline` — Path to the pipeline folder
   - `output_dir` — Output directory
   - `path_to_resource` — Path to resource directory

4. **Submit the job**  
   Run the following command:
   ```bash
   sbatch run/run.sh
   ```

## Example SLURM Script

See `run/run.sh` for a template.  
Key steps:
- Activate the Conda environment.
- Create the output directory.
- Run Nextflow with the specified configuration and parameters.

## Output

- Results will be saved in the specified output directory.
- A report (`report.html`) will be generated summarizing the pipeline run.

## Requirements

- Nextflow >= 23.10
- SLURM cluster
- Conda environment with Nextflow installed